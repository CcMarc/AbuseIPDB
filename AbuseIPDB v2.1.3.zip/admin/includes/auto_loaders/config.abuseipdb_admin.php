<?php
/**
 * Module: AbuseIPDBO
 *
 * @author marcopolo & chatgpt
 * @copyright 2023
 * @license GNU General Public License (GPL)
 * @version v1.0.0
 * @since 4-14-2023
 */
$autoLoadConfig[200][] = array (
    'autoType' => 'init_script',
    'loadFile' => 'init_abuseipdb_observer.php'
);