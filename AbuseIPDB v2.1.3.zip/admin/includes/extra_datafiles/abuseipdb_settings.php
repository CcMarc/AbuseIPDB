<?php
/**
 * Module: AbuseIPDBO
 *
 * @author marcopolo & chatgpt
 * @copyright 2023
 * @license GNU General Public License (GPL)
 * @version v2.0.3
 * @since 4-14-2023
 */
define('TABLE_ABUSEIPDB_CACHE', 'abuseipdb_cache');
define('TABLE_ABUSEIPDB_MAINTENANCE', 'abuseipdb_maintenance');